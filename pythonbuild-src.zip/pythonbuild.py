import tkinter
from tkinter import messagebox
from tkinter import filedialog
import os
from pathlib import Path
import sys
import linecache
import shutil
import platform
if not Path('python_config.conf').is_file():
	messagebox.showerror('Błąd','Błąd przy wczytywaniu informacji o wersji Pythona\nError: FileNotFound: python_config.conf')
	sys.exit(1)
python_path = linecache.getline('python_config.conf',2)
def script():
	global filename1
	filename1 = filedialog.askopenfilename(filetypes=(('Skrypty Pythona','*.py'),('Skrypty Pythona (bez konsoli)','*.pyw')))
	script_info.config(text=filename1)
def folder():
	global foldername
	foldername = filedialog.askdirectory()
	folder_info.config(text=foldername)
def config():
	messagebox.showinfo('Informacja','Kompilacja rozpoczęta')
	try:
		if var1.get()==1:
			os.system(python_path[:-1]+' -m PyInstaller '+filename1+' --onefile --name='+name.get()+' --noconsole '+compiler_args.get())
		if var1.get()==0:
			os.system(python_path[:-1]+' -m PyInstaller '+filename1+' --onefile --name='+name.get()+' '+compiler_args.get())
	except:
		messagebox.showerror('Błąd','Nie można skompilować skryptu: '+filename1)
	shutil.rmtree('build')
	shutil.rmtree(foldername+'/__pycache__')
	os.remove(name.get()+'.spec')
	if platform.system()=='Windows':
		shutil.copy2('dist/'+name.get()+'.exe',foldername)
	elif platform.system()=='macosx':
		shutil.copy2('dist/'+name.get()+'.app',foldername)
	else:
		shutil.copy2('dist/'+name.get(),foldername)
	shutil.rmtree('dist')
	messagebox.showinfo('Informacja','Kompilacja zakończona')
def main():
	global script_info
	global folder_info
	global name
	global noconsole
	global compiler_args
	global var1
	okno = tkinter.Tk()
	var1 = tkinter.IntVar(okno)
	okno.maxsize(400,400)
	okno.minsize(400,400)
	okno.title('Python-Build')
	info1 = tkinter.Label(okno,text='Wybierz skrypt:')
	script_info = tkinter.Label(okno,text='')
	select1 = tkinter.Button(okno,text='...',command=script)
	info2 = tkinter.Label(okno,text='Wybierz folder pliku wyjściowego:')
	folder_info = tkinter.Label(okno,text='')
	select2 = tkinter.Button(okno,text='...',command=folder)
	compiler_info = tkinter.Label(okno,text='Dodatkowe argumenty kompilatora:')
	compiler_args = tkinter.Entry(okno)
	noconsole = tkinter.Checkbutton(okno,text='Bez konsoli',variable=var1)
	name_info = tkinter.Label(okno,text='Nazwa:')
	name = tkinter.Entry(okno)
	compile_button = tkinter.Button(okno,text='Kompiluj',command=config)
	info1.place(x=0,y=0)
	script_info.place(x=0,y=25)
	select1.place(x=0,y=40)
	info2.place(x=0,y=65)
	folder_info.place(x=0,y=85)
	select2.place(x=0,y=100)
	name_info.place(x=0,y=130)
	name.place(x=0,y=160)
	noconsole.place(x=0,y=190)
	compiler_info.place(x=0,y=220)
	compiler_args.place(x=0,y=250)
	compile_button.place(x=0,y=350)
	okno.mainloop()
main()
